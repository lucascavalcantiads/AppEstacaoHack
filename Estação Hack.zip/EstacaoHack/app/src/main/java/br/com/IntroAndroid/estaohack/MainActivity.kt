package br.com.IntroAndroid.estaohack //Definindo o nome do pacote

//Importação das bibliotecas
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() { //Classe dod programa

    override fun onCreate(savedInstanceState: Bundle?) { //Função que vai rodar quando a tela abrir
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Obtendo informação do EditText

        btnLogin.setOnClickListener {
            //Esse metodo é usado para quando o botão for clicado

            val userDefine = "Lucas"
            val passwordDefine = "123"

            val user = edtUser.text.toString().trim() //Pegando o valor do edit text | o .trim elimna os espaços
            val password = edtPassword.text.toString().trim() //Pegando o valor do edit text | o .trim elimna os espaços

            if (user.isNotEmpty() && password.isNotEmpty()) {//Testando se as variáveis estão vazias
                if (userDefine == user && passwordDefine == password) { //Condição para acesso permitido
                    txvResultado.text = "PERMITIDO"
                    txvResultado.setTextColor(Color.GREEN)
                    }else{//Condição para acesso negado
                        txvResultado.text = "NEGADO"
                        txvResultado.setTextColor(Color.RED)
                          }
                }else {//Condição para verificar acesso
                    txvResultado.text = "VERIFICAR"
                    txvResultado.setTextColor(Color.YELLOW)
                      }
        }
    }
}
